import { Component, OnInit } from '@angular/core';

import {
  trigger,
  state,
  style,
  animate,
  transition,
  keyframes,
  query,
  stagger
} from '@angular/animations';

@Component({
  selector: 'pop-over',
  templateUrl: './pop-over.component.html',
  styleUrls: ['./pop-over.component.scss'],
  animations: [
    trigger('popOverState', [
      state('show', style({
        opacity: 1
      })),
      state('hide',   style({
        opacity: 0
      })),
      transition('show => hide', animate('600ms ease-out')),
      transition('hide => show', animate('1000ms ease-in'))
    ]),
    trigger('photoState', [
      state('move', style({
        transform: 'translateX(-100%)',
      })),
      state('enlarge',   style({
        transform: 'scale(1.5)',
      })),
      state('spin',   style({
        transform: 'rotateY(180deg) rotateZ(90deg)',
      })),
      transition('* => move',
      animate('2000ms', keyframes([
        style({transform: 'translateX(0)    rotateY(0)',        offset: 0}),
        style({transform: 'translateX(50%)  rotateY(90deg)',    offset: 0.33}),
        style({transform: 'translateY(-75%) rotateY(180deg)',   offset: 0.66}),
        style({transform: 'translateX(-100%)',                  offset: 1.0})
      ])
    ))
  ]),

  trigger('photosAnimation', [
    transition('* => *', [
      query('img',style({ transform: 'translateX(-100%)'})),
      query('img',
        stagger('600ms', [
          animate('900ms', style({ transform: 'translateX(0)'}))
      ]))
    ])
  ])
]
})
export class PopOverComponent implements OnInit {
  
  show = false;
  constructor() { }
  get stateName() {
    return this.show ? 'show' : 'hide'
  }
  toggle() {
    this.show = !this.show;
  }

position:string;
photoUrl='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_Zh6K_XDakuev39luPvhvSkhM0lGR67e0i_ong4dkU-7tmY1t';

photos=[
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_Zh6K_XDakuev39luPvhvSkhM0lGR67e0i_ong4dkU-7tmY1t',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_Zh6K_XDakuev39luPvhvSkhM0lGR67e0i_ong4dkU-7tmY1t',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_Zh6K_XDakuev39luPvhvSkhM0lGR67e0i_ong4dkU-7tmY1t'
];

changePosition(newPosition:string){
  this.position=newPosition;
}

//trigger code when animation finished
public logAnimation($event) {
  console.log(`${this.position} animation ${$event.phaseName}`)
}

  ngOnInit() {
  }

}
