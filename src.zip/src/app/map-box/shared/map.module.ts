import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AngularFireDatabaseModule } from 'angularfire2/database';

import {FormsModule} from '@angular/forms';

import {MapService} from './map.service';
import { MapBoxComponent } from '../map-box.component';

@NgModule({
  imports: [
    BrowserModule,
    HttpModule,
    AngularFireDatabaseModule,
    FormsModule
  ],
  declarations: [
    MapBoxComponent
  ],
  providers: [
    MapService
  ]
})
export class MapModule { }