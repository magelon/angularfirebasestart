import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

//for 2 way databinding
import {FormsModule} from '@angular/forms';

///// Start FireStarter
import { environment } from '../environments/environment';
import { AngularFireModule } from 'angularfire2';

import {AgmCoreModule} from '@agm/core';

// Core
import { CoreModule } from './core/core.module';

// Shared/Widget
import { SharedModule } from './shared/shared.module'

// Feature Modules
import { ItemModule }   from './items/shared/item.module';
import { UploadModule } from './uploads/shared/upload.module';
import { UiModule }     from './ui/shared/ui.module';
///// End FireStarter


import { SearchUiComponent } from './search-ui/search-ui.component';

import { ReactiveFormsModule } from '@angular/forms';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';


import { PopOverComponent } from './pop-over/pop-over.component';

import {MapModule} from'./map-box/shared/map.module';



import {ChartService} from './chart.service';

import {MoviesListModule} from './movies-list/shared/movies-list.module';

import {AdListingModule} from './ad-listing/shared/ad-listing.module';

import {AnimalsListModule} from './animals-list/shared/animals-list.module';

import {GmapModule} from './gmap/shared/gmap.module';

import 'hammerjs';

@NgModule({
  declarations: [
    AppComponent,  
    SearchUiComponent,
    PopOverComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    CoreModule,
    SharedModule,
    ItemModule,
    UiModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),   
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    MoviesListModule ,
    MapModule,
    AdListingModule,
    AnimalsListModule,
    GmapModule,
    AgmCoreModule.forRoot({
      apiKey:environment.googleMapsKey
    })
  ],
  providers:[
    ChartService
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
