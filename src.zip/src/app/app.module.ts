import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

//for 2 way databinding
import {FormsModule} from '@angular/forms';

///// Start FireStarter
import { environment } from '../environments/environment';
import { AngularFireModule } from 'angularfire2';


// Core
import { CoreModule } from './core/core.module';

// Shared/Widget
import { SharedModule } from './shared/shared.module'

// Feature Modules
import { ItemModule }   from './items/shared/item.module';
import { UploadModule } from './uploads/shared/upload.module';
import { UiModule }     from './ui/shared/ui.module';
///// End FireStarter

import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import {MovieService} from './movie.service';

import { MoviesListComponent } from './movies-list/movies-list.component';
import { SearchUiComponent } from './search-ui/search-ui.component';

import { ReactiveFormsModule } from '@angular/forms';

import {AdService} from'./ad.service';
import { AdListingComponent } from './ad-listing/ad-listing.component';

import {FollowService} from './follow.service';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';


import { PopOverComponent } from './pop-over/pop-over.component';

import {MapService} from './map.service';
import { MapBoxComponent } from './map-box/map-box.component';
import { AnimalsListComponent } from './animals-list/animals-list.component';

@NgModule({
  declarations: [
    AppComponent,
    MoviesListComponent,
    SearchUiComponent,
    AdListingComponent,
    
    PopOverComponent,
    
    MapBoxComponent,
    
    AnimalsListComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    CoreModule,
    SharedModule,
    ItemModule,
    UiModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    InfiniteScrollModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule 
  ],
  providers:[
    MovieService,
    AdService,
    FollowService,
    MapService
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
