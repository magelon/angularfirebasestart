import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseObjectObservable } from 'angularfire2/database';

export class AdListing {
  Name    = 'Your Title'
  Image    = 'http://via.placeholder.com/350x150'
  Family  = 'Ad Content'
  Weight    = 5.00
  content =''
  
}

@Injectable()
export class AdService {

  constructor(private db: AngularFireDatabase) { }
  /// Creates an Ad, then returns as an object
  createAd(): FirebaseObjectObservable<AdListing> {
    const adDefault = new AdListing()
    const adKey = this.db.list('/animals').push(adDefault).key
    return this.db.object('/animals/' + adKey)
  }
  /// Updates an existing Ad
  updateAd(ad: FirebaseObjectObservable<AdListing>, data: any) {
    return ad.update(data)
  }

}
