import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseListObservable, FirebaseObjectObservable } from 'angularfire2/database';
import {AngularFireAuth} from 'angularfire2/auth';
import * as firebase from 'firebase';
import * as _ from 'lodash';

export class AdListing {
  Name    = 'Your Title'
  Image    = 'http://via.placeholder.com/350x150'
  Family  = 'Ad Content'
  Weight    = 5.00
  content =''
  owner =''
  oname =''
  sortDate=0
}



@Injectable()
export class AdService {

userId:string;
oname:string;
sortDate;

  constructor(private db: AngularFireDatabase,
    private auth:AngularFireAuth) {
      this.auth.authState.subscribe(user=>{
        if(user){
          this.userId=user.uid
          this.oname=user.displayName
          
        }
      })
     }
  /// Creates an Ad, then returns as an object
  createAd(): FirebaseObjectObservable<AdListing> {
    const adDefault = new AdListing()
    adDefault.owner=this.userId
    adDefault.oname=this.oname

  

    this.sortDate= 99999999999999999-Date.now()
    adDefault.sortDate=Date.now()

    this.db.object(`/animals/${this.sortDate}`).set(adDefault)
    const adKey = this.sortDate
    //this.db.list('/animals').push(adDefault).key
    
   
    return this.db.object('/animals/' + adKey)
  }
  /// Updates an existing Ad
  updateAd(ad: FirebaseObjectObservable<AdListing>, data: any) {
    return ad.update(data)
  }

// Deletes a single item
deleteAnimal(key: string): void {
  this.db.list('/animals').remove(key)
}

getAnimal(key:string) {
return this.db.object('/animals/'+key)
}

  getAnimals() {
    let query =  {
           orderByChild:'owner',
           equalTo: this.userId
          }
    return this.db.list('/animals', {
      query
    })
  }

}
