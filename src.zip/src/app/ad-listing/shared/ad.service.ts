import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseListObservable, FirebaseObjectObservable } from 'angularfire2/database';
import {AngularFireAuth} from 'angularfire2/auth';
import * as firebase from 'firebase';

export class AdListing {
  Name    = 'Your Title'
  Image    = 'http://via.placeholder.com/350x150'
  Family  = 'Ad Content'
  Weight    = 5.00
  content =''
  owner =''
  
}

@Injectable()
export class AdService {

  userId:string;

  constructor(private db: AngularFireDatabase,
    private auth:AngularFireAuth) {
      this.auth.authState.subscribe(user=>{
        if(user)this.userId=user.uid
      })
     }
  /// Creates an Ad, then returns as an object
  createAd(): FirebaseObjectObservable<AdListing> {
    const adDefault = new AdListing()
    adDefault.owner=this.userId
    const adKey = this.db.list('/animals').push(adDefault).key
    return this.db.object('/animals/' + adKey)
  }
  /// Updates an existing Ad
  updateAd(ad: FirebaseObjectObservable<AdListing>, data: any) {
    return ad.update(data)
  }

}
