import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseObjectObservable } from 'angularfire2/database';


import {AngularFireAuth} from 'angularfire2/auth';

import {AdListing} from './ad-listing';

import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';

@Injectable()
export class AdService {
  userId:string;
  constructor(private db: AngularFireDatabase,
    private afAuth:AngularFireAuth) {
      this.afAuth.authState.subscribe(user => {
        if(user){
          this.userId=user.uid
        }
      })
   }

  /// Creates an Ad, then returns as an object
  createAd(): FirebaseObjectObservable<AdListing> {
    const adDefault = new AdListing()
    adDefault.owner=this.userId
    const adKey = this.db.list('/animals').push(adDefault).key
    return this.db.object('/animals/' + adKey)
  }
  /// Updates an existing Ad
  updateAd(ad: FirebaseObjectObservable<AdListing>, data: any) {
    return ad.update(data)
  }


}
