
export class AdListing {
    Name    = 'Your Title'
    Image   = 'http://via.placeholder.com/350x150'
    Family  = 'Ad Content'
    Weight  = 5.00
    content = ''
    owner = 'userId'
  }