import { Component, OnInit } from '@angular/core';
import { AdService, AdListing } from './shared/ad.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AngularFireDatabase, FirebaseListObservable, FirebaseObjectObservable } from 'angularfire2/database';
import * as firebase from 'firebase';

@Component({
  selector: 'ad-listing',
  templateUrl: './ad-listing.component.html',
  styleUrls: ['./ad-listing.component.scss']
})
export class AdListingComponent implements OnInit {

 
  ad: any;
  adForm: FormGroup;


  alist: FirebaseListObservable<AdListing[]> = null; //  list of objects

  constructor(private adService: AdService, private fb: FormBuilder) { }
  startNewAdListing() {
    this.ad =     this.adService.createAd()
    this.buildForm()
  }
  saveAdChanges() {
    if (this.adForm.status != 'VALID') {
      console.log('form is not valid, cannot save to database')
      return
    }
    const data = this.adForm.value
    this.adService.updateAd(this.ad, data)
  }
  private buildForm() {
    this.adForm = this.fb.group({

      Name   : ['', Validators.required ],
      Image   : ['', Validators.required ],
      Family  : ['', Validators.required ],
      Weight   : ['', Validators.required ],
      link    :[''],
      content : ['', Validators.required ]

    });
    this.ad.subscribe(ad => {
      this.adForm.patchValue(ad)
    })
  }

  ngOnInit() {
    this.alist=this.adService.getAnimals()
  }

   // Deletes a single item
   deleteItem(key: string): void {
    this.adService.deleteAnimal(key)
  }

  editAnimal(key:string) {
    this.ad = this.adService.getAnimal(key)
    this.buildForm()
  }

}
