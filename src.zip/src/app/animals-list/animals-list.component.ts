import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';


import * as _ from 'lodash';

@Component({
  selector: 'animals-list',
  templateUrl: './animals-list.component.html',
  styleUrls: ['./animals-list.component.scss']
})
export class AnimalsListComponent implements OnInit {

  constructor(private db: AngularFireDatabase) { }
  /// unwrapped arrays from firebase
  itemId:any;
 animals: any;
 filteredAnimals: any;
 /// filter-able properties
 family:     string;
 weight:     number;
 endangered: boolean;
 /// Active filter rules
 filters = {}
 ngOnInit() {
   this.db.list('/animals')
     .subscribe(animals => {
       this.animals = animals;
       this.applyFilters()
   })
 }
 private applyFilters() {
   this.filteredAnimals = _.filter(this.animals, _.conforms(this.filters) )
 }
 /// filter property by equality to rule
 filterExact(property: string, rule: any) {
   this.filters[property] = val => val == rule
   this.applyFilters()
 }
 /// filter  numbers greater than rule
 filterGreaterThan(property: string, rule: number) {
   this.filters[property] = val => val > rule
   this.applyFilters()
 }
 /// filter properties that resolve to true
 filterBoolean(property: string, rule: boolean) {
   if (!rule) this.removeFilter(property)
   else {
     this.filters[property] = val => val
     this.applyFilters()
   }
 }
 /// removes filter
 removeFilter(property: string) {
   delete this.filters[property]
   this[property] = null
   this.applyFilters()
 }
}