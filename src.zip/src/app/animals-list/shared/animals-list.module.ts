import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';


import { AnimalsListComponent } from '../animals-list.component';

import {MdCardModule} from '@angular/material';
import {MdGridListModule} from '@angular/material';

import { DisqusModule } from 'angular2-disqus';

import {ReactionComponent} from '../../ui/reaction/reaction.component';
import {FollowComponent} from '../../ui/follow/follow.component';

import {AnimalsListService} from './animals-list.service';

import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  imports: [
    CommonModule,
    MdCardModule,
    FormsModule,
    MdGridListModule,
    DisqusModule,
    InfiniteScrollModule
  ],
  declarations: [
    AnimalsListComponent,
    ReactionComponent,
    FollowComponent
  ],
  providers:[
    AnimalsListService
  ]
})
export class AnimalsListModule { }
