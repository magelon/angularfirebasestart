import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';


import { AnimalsListComponent } from '../animals-list.component';

import {MdCardModule} from '@angular/material';
import {MdGridListModule} from '@angular/material';

import { DisqusModule } from 'angular2-disqus';

@NgModule({
  imports: [
    CommonModule,
    MdCardModule,
    FormsModule,
    MdGridListModule,
    DisqusModule,
  ],
  declarations: [
    AnimalsListComponent,
  ]
})
export class AnimalsListModule { }
