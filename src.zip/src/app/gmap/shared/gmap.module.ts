import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {environment} from '../../../environments/environment';
import {AngularFireModule} from 'angularfire2';

import {AgmCoreModule} from '@agm/core';

import {GmapComponent} from '../gmap.component';
import {GmapService} from './gmap.service'

@NgModule({
  imports: [
    CommonModule,
    AgmCoreModule.forRoot({
      apiKey:environment.googleMapsKey
    })
  ],
  declarations: [
    GmapComponent
  ],
  providers: [
    GmapService
  ]
})
export class GmapModule { }
