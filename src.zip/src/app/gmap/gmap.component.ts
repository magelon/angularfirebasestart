import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gmap',
  templateUrl: './gmap.component.html',
  styleUrls: ['./gmap.component.scss']
})
export class GmapComponent implements OnInit {

  lat: number=37.542143;
  lng: number=-121.989947;
  constructor() { }
  ngOnInit() {
    
    this.getUserLocation()
    console.log(navigator.geolocation)
    
   
  }
  private getUserLocation() {
   /// locate the user
   if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
       this.lat = position.coords.latitude;
      
       this.lng = position.coords.longitude;
     });
   }
 }

}
