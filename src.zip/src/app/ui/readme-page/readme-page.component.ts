import { Component, OnInit,ViewChild, ElementRef } from '@angular/core';

import { ChartService} from '../../chart.service'
import * as _ from 'lodash'

@Component({
  selector: 'readme-page',
  templateUrl: './readme-page.component.html',
  styleUrls: ['./readme-page.component.scss']
})
export class ReadmePageComponent implements OnInit {

  @ViewChild('chart') el: ElementRef;

  constructor(private chartService: ChartService) { }

  ngOnInit() {
    this.basicChart()
  }

  basicChart() {
    const element = this.el.nativeElement
    const data = [{
      x: [1, 2, 3, 4, 5],
      y: [1, 2, 4, 8, 16]
    }]
    const style = {
      margin: { t: 0 }
    }
    Plotly.plot( element, data, style )
  }

}
