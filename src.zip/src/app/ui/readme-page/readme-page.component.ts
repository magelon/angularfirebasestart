import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'readme-page',
  templateUrl: './readme-page.component.html',
  styleUrls: ['./readme-page.component.scss']
})
export class ReadmePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
