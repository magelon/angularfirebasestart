import { Component, OnInit,OnDestroy } from '@angular/core';
import { Router } from "@angular/router";

import { AuthService,User } from "../../core/auth.service";
import { FirebaseListObservable } from 'angularfire2/database';

import { ReactiveFormsModule } from '@angular/forms';

import { size } from "lodash";

@Component({
  selector: 'user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.scss']
})
export class UserLoginComponent implements OnInit {

  Users: FirebaseListObservable<User[]> = null;
 

  constructor(
    public auth: AuthService,
    private router: Router) { }


  ngOnInit() {
    this.Users=this.auth.getUsers()
    
      }

  /// Social Login

  signInWithGithub(): void {
    this.auth.githubLogin()
    .then(() => this.afterSignIn());
  }

  signInWithGoogle(): void {
    this.auth.googleLogin()
      .then(() => this.afterSignIn());
  }

  signInWithFacebook(): void {
    this.auth.facebookLogin()
      .then(() => this.afterSignIn());
  }

  signInWithTwitter(): void {
    this.auth.twitterLogin()
      .then(() => this.afterSignIn());
  }

  /// Anonymous Sign In

  signInAnonymously() {
    this.auth.anonymousLogin()
      .then(() => this.afterSignIn());
  }


  /// Shared

  private afterSignIn(): void {
    // Do after login stuff here, such router redirects, toast messages, etc.
    this.router.navigate(['/']);
  }

}
