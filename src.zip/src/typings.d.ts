/* SystemJS module definition */
declare var module: {
  id: string;
};

declare var Plotly: any;