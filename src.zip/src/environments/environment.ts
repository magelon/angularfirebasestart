// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,

  firebaseConfig:{
    apiKey: "AIzaSyDKHeUBVNHM8ve0HEM3AwT680rpvw4034E",
    authDomain: "upload-31cd5.firebaseapp.com",
    databaseURL: "https://upload-31cd5.firebaseio.com",
    projectId: "upload-31cd5",
    storageBucket: "upload-31cd5.appspot.com",
    messagingSenderId: "27866717974"
  },

  algolia:{
    appId:'R6KZD8ZLNS',
    apiKey:'ae1c3d2249cb1de3cce8f71045d43b22',
    indexName:'getstarted_actors',
    urlSync:false

  },

  mapbox:{
    accessToken:'pk.eyJ1IjoiZ3VvamluZG9uZyIsImEiOiJjajZuMndhNzAwNDk5MnFsYTc0ZXg3cW9mIn0.Abnroi4CyO829oqPDzn_hA'
  },

googleMapsKey:'AIzaSyDczj0igabo5Qh5V7DaxcEI50jdEO2Dl8E'

};

