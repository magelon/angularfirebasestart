import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class SharedService {

private source= new BehaviorSubject <string>(" ");
private source2 = new BehaviorSubject<string>("");

currenSource =this.source.asObservable();
currenSource2 =this.source2.asObservable();

  constructor() { }
    changeSource(source:string,source2:string){
      this.source.next(source)
      this.source2.next(source2)
    }
}
