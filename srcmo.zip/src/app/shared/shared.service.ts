import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class SharedService {

private source= new BehaviorSubject <string>(" ");
currenSource =this.source.asObservable();
  constructor() { }
    changeSource(source:string){
      this.source.next(source)
    }
}
