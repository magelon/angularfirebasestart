import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';

import { AnimalPageComponent } from '../animal-page.component';
import {AnimalPageService} from './animal-page.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    AnimalPageComponent
  ],
  providers:[
    AnimalPageService
  ]
})
export class AnimalPageModule { }
