import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import * as firebase from 'firebase';

export class AdListing {
  Name    = 'Your Title'
  Image    = 'http://via.placeholder.com/350x150'
  Family  = 'Ad Content'
  Weight    = 5.00
  link =''
  content =''
  owner =''
  oname =''
  sortDate=0
}

@Injectable()
export class AnimalPageService {

  

  constructor(private db: AngularFireDatabase) { }

  getAnimal(id:string) {

    }

  
      
  }


