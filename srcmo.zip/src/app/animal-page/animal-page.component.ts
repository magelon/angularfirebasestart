import { Component, OnInit } from '@angular/core';
import {SharedService} from '../shared/shared.service';

@Component({
  selector: 'animal-page',
  templateUrl: './animal-page.component.html',
  styleUrls: ['./animal-page.component.scss']
})
export class AnimalPageComponent implements OnInit {

source:string;

  constructor(private shared:SharedService) { }

  ngOnInit() {
    this.shared.currenSource.subscribe(s=>this.source=s)
  }

}
