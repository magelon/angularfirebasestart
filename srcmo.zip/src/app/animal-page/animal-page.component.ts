import { Component, OnInit } from '@angular/core';
import {SharedService} from '../shared/shared.service';
import {AnimalPageService,AdListing} from './share/animal-page.service';
import {ActivatedRoute} from '@angular/router';

import { AngularFireDatabase,FirebaseListObservable, FirebaseObjectObservable  } from 'angularfire2/database';
import * as firebase from 'firebase';

@Component({
  selector: 'animal-page',
  templateUrl: './animal-page.component.html',
  styleUrls: ['./animal-page.component.scss']
})
export class AnimalPageComponent implements OnInit {

source:string;
source2:string;
id;
page;
animal:any;

  constructor(
    private route:ActivatedRoute,
    private shared:SharedService,
    private aps:AnimalPageService,
    private db:AngularFireDatabase){ 
      
     

      if(this.source==null){
      this.id =route.snapshot.params['id'];

      
      this.animal=this.db.list('animals',{
        query:{
          orderByKey:true,
          equalTo:this.id,
          limitToFirst:1
        }
      })
    }
    
    }



  ngOnInit() {
    this.shared.currenSource.subscribe(s=>this.source=s)
   
    this.page=`https://upload-31cd5.firebaseapp.com/page/${this.source}`
    

    this.shared.currenSource2.subscribe(s=>this.source2=s)
  }

  
 

}
