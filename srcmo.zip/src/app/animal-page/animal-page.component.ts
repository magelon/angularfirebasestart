import { Component, OnInit } from '@angular/core';
import {SharedService} from '../shared/shared.service';
import {AnimalPageService} from './share/animal-page.service';

@Component({
  selector: 'animal-page',
  templateUrl: './animal-page.component.html',
  styleUrls: ['./animal-page.component.scss']
})
export class AnimalPageComponent implements OnInit {

source:string;
source2:string;
  constructor(private shared:SharedService,private aps:AnimalPageService) { }

  ngOnInit() {
    this.shared.currenSource.subscribe(s=>this.source=s)
    this.shared.currenSource2.subscribe(s=>this.source2=s)
  }

  
 

}
