import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { FollowService } from "../shared/follow.service";
import { size } from "lodash";
import { AuthService } from "../../core/auth.service";

@Component({
  selector: 'follow',
  templateUrl: './follow.component.html',
  styleUrls: ['./follow.component.scss']
})
export class FollowComponent implements OnInit,  OnDestroy {
  @Input() user;        // a user who can be followed
  @Input() name;
  //currentUser; // currently logged in user
  followerCount: number;
  isFollowing: boolean;
  followers;
  following;
  constructor(private followSvc: FollowService,
  private auth: AuthService) { }
  ngOnInit() {
    const userId = this.user//.$key
    const currentUserId = this.auth.currentUserId
    // checks if the currently logged in user is following this.user
    this.following = this.followSvc.getFollowing(currentUserId, userId)
                                   .subscribe(following => {
                                      this.isFollowing = following.$value
                                    })
    // retrieves the follower count for a user's profile
    this.followers = this.followSvc.getFollowers(userId)
                                   .subscribe(followers => {
                                     this.followerCount = this.countFollowers(followers)
                                    })
  }
  private countFollowers(followers) {
    if (followers.$value===null) return 0
    else return size(followers)
  }
  toggleFollow() {
    const userId = this.user//.$key
    const currentUserId = this.auth.currentUserId
    if (this.isFollowing) this.followSvc.unfollow(currentUserId, userId)
    else this.followSvc.follow(currentUserId, userId)
  }
  ngOnDestroy() {
    this.followers.unsubscribe()
    this.following.unsubscribe()
  }
}