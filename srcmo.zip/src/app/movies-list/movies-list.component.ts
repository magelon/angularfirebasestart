import { Component, OnInit } from '@angular/core';
import { MovieService } from './shared/movie.service'
import { BehaviorSubject } from 'rxjs/BehaviorSubject'
import * as _ from 'lodash'
import {Subject} from 'rxjs/Subject';

@Component({
  selector: 'movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.scss']
})
export class MoviesListComponent implements OnInit {
  
smovies;
startAt = new Subject()
endAt = new Subject()
lastKeypress: number = 0;

  movies = new BehaviorSubject([]);
  batch = 2         // size of each query
  lastKey = ''      // key to offset next query from
  finished = false  // boolean when end of database is reached
  constructor(private movieService: MovieService) { }
  ngOnInit() {
    this.getMovies();
    this.movieService.searchMovies(this.startAt,this.endAt)
    .subscribe(smovies=>this.smovies=smovies);
  }

search($event){
  if ($event.timeStamp - this.lastKeypress > 200) {
    let q = $event.target.value
    this.startAt.next(q)
    this.endAt.next(q+"\uf8ff")
  }
  this.lastKeypress = $event.timeStamp
}

  onScroll () {
    console.log('scrolled!!')
    this.getMovies()
  }
  private getMovies(key?) {
    if (this.finished) return
    this.movieService
        .getMovies(this.batch+1, this.lastKey)
        .do(movies => {
          /// set the lastKey in preparation for next query
          this.lastKey = _.last(movies)['$key']
          const newMovies = _.slice(movies, 0, this.batch)
          /// Get current movies in BehaviorSubject
          const currentMovies = this.movies.getValue()
          /// If data is identical, stop making queries
          if (this.lastKey == _.last(newMovies)['$key']) {
            this.finished = true
          }
          /// Concatenate new movies to current movies
          this.movies.next( _.concat(currentMovies, newMovies) )
        })
        .take(1)
        .subscribe()
  }
}
