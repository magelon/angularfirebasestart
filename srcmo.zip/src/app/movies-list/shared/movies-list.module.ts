

import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';
import { AngularFireDatabaseModule } from 'angularfire2/database';


import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import {MovieService} from './movie.service';

import { MoviesListComponent } from '../../movies-list/movies-list.component';


@NgModule({
    declarations: [
       
      MoviesListComponent,
     
    ],
    imports: [
        BrowserModule,
      AngularFireDatabaseModule,
      InfiniteScrollModule
    ],
    providers:[
      MovieService
     
    ]
  })
  export class MoviesListModule { }