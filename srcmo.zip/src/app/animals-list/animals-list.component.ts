import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';

import { AnimalsListService } from './shared/animals-list.service'
import { BehaviorSubject } from 'rxjs/BehaviorSubject'

import {SharedService} from '../shared/shared.service';
import {Subject} from 'rxjs/Subject'

import * as _ from 'lodash';

@Component({
  selector: 'animals-list',
  templateUrl: './animals-list.component.html',
  styleUrls: ['./animals-list.component.scss']
})
export class AnimalsListComponent implements OnInit {

  source:string;
  source2:string;

    Ianimals = new BehaviorSubject([]);
    batch = 2         // size of each query
    lastKey = ''      // key to offset next query from
    finished = false  // boolean when end of database is reached

  constructor(
    private shared:SharedService,
    private db: AngularFireDatabase,
  private animalService:AnimalsListService) { }
  /// unwrapped arrays from firebase
  itemId:any;
 animals: any;
 filteredAnimals: any;
 /// filter-able properties
 family:     string;
 weight:     number;
 endangered: boolean;
 /// Active filter rules
 filters = {}

 ngOnInit() {

this.shared.currenSource.subscribe(s=>this.source=s)
this.shared.currenSource2.subscribe(s=>this.source2=s)

   this.getIanimals()

   this.db.list('/animals')
     .subscribe(animals => {
       this.animals = animals;
       this.applyFilters()
   })
 }

newSource(an:string,i:string){
  this.shared.changeSource(an,i);
  console.log(this.source);
}

 onScroll () {
  console.log('scrolled!!')
  this.getIanimals()
}
private getIanimals(key?) {
  if (this.finished) return
  this.animalService
      .getAnimals(this.batch+1, this.lastKey)
      .do(movies => {
        /// set the lastKey in preparation for next query
        this.lastKey = _.last(movies)['$key']
        const newMovies = _.slice(movies,0,this.batch)
        /// Get current movies in BehaviorSubject
        const currentMovies = this.Ianimals.getValue()
        
        /// If data is identical, stop making queries
        if (this.lastKey == _.last(newMovies)['$key']) {
          this.finished = true
        }
        /// Concatenate new movies to current movies
        this.Ianimals.next( _.concat(currentMovies, newMovies) )
      })
      .take(1)
      .subscribe()
}


 private applyFilters() {
   this.filteredAnimals = _.filter(this.animals, _.conforms(this.filters) )
 }
 /// filter property by equality to rule
 filterExact(property: string, rule: any) {
   this.filters[property] = val => val == rule
   this.applyFilters()
 }
 /// filter  numbers greater than rule
 filterGreaterThan(property: string, rule: number) {
   this.filters[property] = val => val > rule
   this.applyFilters()
 }
 /// filter properties that resolve to true
 filterBoolean(property: string, rule: boolean) {
   if (!rule) this.removeFilter(property)
   else {
     this.filters[property] = val => val
     this.applyFilters()
   }
 }
 /// removes filter
 removeFilter(property: string) {
   delete this.filters[property]
   this[property] = null
   this.applyFilters()
 }
}