import { TestBed, inject } from '@angular/core/testing';

import { AnimalsListService } from './animals-list.service';

describe('AnimalsListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AnimalsListService]
    });
  });

  it('should be created', inject([AnimalsListService], (service: AnimalsListService) => {
    expect(service).toBeTruthy();
  }));
});
