import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import {AngularFireAuth} from 'angularfire2/auth';
import * as firebase from 'firebase';

@Injectable()
export class AnimalsListService {

  userId;

  constructor(private db: AngularFireDatabase,
  private au:AngularFireAuth) { 
    this.au.authState.subscribe(user=>{
      if(user){
        this.userId=user.uid  
      }
    })
  }

animals;

  getAnimals(batch, lastKey?) {
    let query =  {
            orderByKey:true,
            
            limitToFirst: batch,
          }
    if (lastKey) query['startAt'] = lastKey

this.animals=this.db.list('/animals', {
  query
})
    return this.animals;
  }
 
  searchAnimals(start,end):FirebaseListObservable<any>{
    return this.db.list('/animals',{
      query:{
        orderByChild:'Family',
        limitToFirst:10,
        startAt:start,
        endAt:end
      }
    });
}

}
