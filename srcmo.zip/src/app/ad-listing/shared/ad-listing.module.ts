

import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';
import { AngularFireDatabaseModule } from 'angularfire2/database';

import { ReactiveFormsModule } from '@angular/forms';
import {FormsModule} from '@angular/forms';

import {AdService} from './ad.service';

import { AdListingComponent } from '../ad-listing.component';


@NgModule({
    declarations: [
       
        AdListingComponent
     
    ],
    imports: [
        BrowserModule,
      AngularFireDatabaseModule,
      ReactiveFormsModule,
      FormsModule
    ],
    providers:[
      AdService
     
    ]
  })
  export class AdListingModule { }