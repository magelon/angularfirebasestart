import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/auth.guard';

import { UserLoginComponent } from './ui/user-login/user-login.component';
import { ItemsListComponent } from './items/items-list/items-list.component';
// import { UploadsListComponent } from './uploads/uploads-list/uploads-list.component';
import { ReadmePageComponent } from './ui/readme-page/readme-page.component';

import { CoreModule } from './core/core.module'

import {MoviesListComponent} from './movies-list/movies-list.component';
import{SearchUiComponent} from './search-ui/search-ui.component';
import { AdListingComponent } from './ad-listing/ad-listing.component';

import {PopOverComponent} from './pop-over/pop-over.component';
import {MapBoxComponent} from './map-box/map-box.component';
import {AnimalsListComponent} from './animals-list/animals-list.component';
import {GmapComponent} from './gmap/gmap.component';
import {AnimalPageComponent} from './animal-page/animal-page.component';

const routes: Routes = [
  { path: '', component: ReadmePageComponent },
  { path: 'login', component: UserLoginComponent, },
  { path: 'items', component: ItemsListComponent, canActivate: [AuthGuard]},
  { path: 'uploads', loadChildren: "./uploads/shared/upload.module#UploadModule" },
  // { path: 'uploads', component: UploadsListComponent, canActivate: [AuthGuard]},
  {path:'movies',component:MoviesListComponent},
  {path:'actorsearch',component:SearchUiComponent},
  {path:'reactform',component:AdListingComponent,canActivate: [AuthGuard]},
  {path:'popover',component:PopOverComponent},
  {path:'map',component:MapBoxComponent},
  {path:'animals',component:AnimalsListComponent},
  {path:'gmap',component:GmapComponent},
  {path:'page',component:AnimalPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard]
})
export class AppRoutingModule { }
